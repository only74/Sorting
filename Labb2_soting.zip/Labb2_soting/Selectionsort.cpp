#include "Selectiosort.h"
#include "Timer.h"
std::vector<int> SelectionSort (std::vector<int>& data){
    for(int i = 0; i <data.size() - 1; i++){        
        int min_index = i;
        for(int j = i+1; j < data.size(); j++){
            if (data[j]<data[min_index]){
                min_index = j;
            }
        }
        std::swap(data[i], data[min_index]);
    }
    return data;
}