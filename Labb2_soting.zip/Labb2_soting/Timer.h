#pragma once
#ifndef TIMER_H
#define TIMER_H
#include <vector>
#include <iostream>
#include <algorithm>
#include <chrono>
#include "Insertionsort.h"
#include "Selectiosort.h"
#include "Quicksort.h"


double time_sort(std::vector<int>(*sort_func)(std::vector<int>&), std::vector<int>& data);

#endif // TIMER_H