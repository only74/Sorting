
#include "Timer.h"
// Funktionsmall för att mäta tid för en given sorteringsfunktion
double time_sort(std::vector<int>(*sort_func)(std::vector<int>&), std::vector<int>& data) {
    auto start = std::chrono::high_resolution_clock::now();
    sort_func(data);
    auto stop = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> total = (stop - start);
    return total.count();
}