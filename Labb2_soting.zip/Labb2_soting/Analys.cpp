#include <vector>
#include <numeric>
#include <cmath>
#include <algorithm>

/**
 * Calculates the average value of a vector of doubles.
 *
 * @param data The vector of doubles.
 * @return The average value of the vector.
 */
double average_value(const std::vector<double> &data)
{
    double sum = std::accumulate(data.begin(), data.end(), 0.0);
    const size_t N = data.size();
    double avg = sum / N;

    return avg;
}

/**
 * Calculates the standard deviation of a vector of doubles.
 *
 * @param data The vector of doubles.
 * @return The standard deviation of the vector.
 */
double std_dev(std::vector<double> &data)
{
    const size_t N = data.size();
    // Calculate the average value of the vector
    double avg_val = average_value(data);
    double dev_square = 0;

    // Iterate through each value in the vector and calculate the squared deviation
    for (std::vector<double>::iterator itr = data.begin(); itr != data.end(); itr++)
    {
        dev_square += pow((*itr - avg_val), 2);
    }

    // Calculate the standard deviation by taking the square root of the average squared deviation
    return std::sqrt(dev_square * (1.0 / (N - 1)));
}