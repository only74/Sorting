#pragma once
#ifndef SELECTIONSORT_H
#define SELECTIONSORT_H
#include <vector>

std::vector<int> SelectionSort(std::vector<int>& data);

#endif //SELECTIONSORT_H