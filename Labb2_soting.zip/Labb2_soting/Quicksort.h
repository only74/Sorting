#pragma once
#ifndef QUICKSORT_H
#define QUICKSORT_H

#include <vector>

int partitioning(std::vector<int> &data, int low, int high);
std::vector<int> QuickSort(std::vector<int> &data, int low, int high);
int MedianOfThree (std::vector<int>& data, int low, int high);

#endif //QUICKSORT_H