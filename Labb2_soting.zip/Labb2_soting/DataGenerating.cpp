#include "DataGenerating.h"

std::vector<int> DataGenerator::RandomData(int size)
{

    std::vector<int> data(size);
    for (int i = 0; i < size; ++i)
    {
        data[i] = std::rand(); // Använd std::rand för slumpmässiga tal
    }
    return data;
}

std::vector<int> DataGenerator::AscendingData(int size)
{
    std::vector<int> data(size);
    for (int i = 0; i < size; ++i)
    {
        data[i] = i + 1; // Monotont stigande
    }
    return data;
}

std::vector<int> DataGenerator::DescendingData(int size)
{
    std::vector<int> data(size);
    for (int i = 0; i < size; ++i)
    {
        data[i] = size - i; // Monotont fallande
    }
    return data;
}

std::vector<int> DataGenerator::ConstantData(int value, int size)
{
    std::vector<int> data(size, value); // Alla element i vektorn är samma
    return data;
}