#include "Quicksort.h"
#include "Timer.h"
//function to split the array into 2 subarrays, by slection pivot element
int partitioning(std::vector<int> &data, int low, int high)
{
    //picking the rightmost value as pivot
    int pivot = high;
    int LHS = low - 1;
    //loop through the array from the low index to the high index -1
    for (int pos = low; pos <= high - 1; pos++)
    {
        //if current element is smaller than the pivot.
        if (data[pos] <= data[pivot])
        {
            //increment index of smaller element
            LHS++;
            // Swaps value with the new right most position for the left hand side of the pivot
            std::swap(data[LHS], data[pos]);
        }
    }
    // Swaps rightmost position of left hand side +1 with the pivot
    std::swap(data[LHS + 1], data[pivot]);
    // Returns rightmost position of left hand side +1 to get pivot position
    return LHS + 1;
}
//function to sort a vector of integers using quicksort
std::vector<int> QuickSort(std::vector<int> &data, int low, int high)
{
    //Check if the array has more than one element
    if (low < high)
    {
        //Partitions the array to get the pivotposition
        int pivot = partitioning(data, low, high);
        //Recursively sort the subarrays on both sides of the pivot.
        data = QuickSort(data, low, pivot - 1);
        data = QuickSort(data, pivot + 1, high);
    }
    return data;
}
int MedianOfThree (std::vector<int>& data, int low, int high){
    //Finding the middle value
    int mid = ((high - low)/2) + low;
    //Finding the median value
    int pivot;
    //Setting the pivot to the position of the median value
    if(data[low] > data[mid]){
        std::swap(data[low],data[mid]);
    }
    if(data[low] > data[high]){
        std::swap(data[low],data[high]);
    }
    if(data[mid] > data[high]){
        std::swap(data[mid],data[high]);
    }
    std::swap(data[mid],data[high-1]);
    pivot = high-1;
    int LHS = low;
    for (int pos = low+1; pos <= pivot-1; pos++)
    {
        //Checking if value is smaller than pivot
        if(data[pos] <= data[pivot]){
            LHS++;
            //Swaps value with the new right most position for the left hand side of the pivot
            std::swap(data[LHS], data[pos]);
        }
    }
    //Swaps rightmost position of left hand side +1 with the pivot
    std::swap(data[LHS+1], data[pivot]);

    //Returns rightmost position of left hand side +1 to get pivot position
    return LHS+1;
}