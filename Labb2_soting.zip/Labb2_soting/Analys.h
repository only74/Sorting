#pragma once
#ifndef ANALYS_H
#define ANALYS_H

#include <vector>
#include <numeric>
#include <cmath>
#include <algorithm>

double average_value(const std::vector<double>& data);
double std_dev(std::vector<double>& data);

#endif //ANALYS_H