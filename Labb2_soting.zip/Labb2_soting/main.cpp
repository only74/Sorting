
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <functional>
#include <cassert>
#include "Timer.h"
#include "Insertionsort.h"
#include "DataGenerating.h"
#include "Quicksort.h"
#include "Selectiosort.h"
#include "Analys.h"

const int SIZE = 2'000;
const int REPETITIONS = 10;
const int SAMPLES = 5;

int main()
{
    std::vector<int> data;
    std::vector<int> copy;
    std::vector<double> period(SAMPLES);
    // std::vector<int> descending_data;

    std::ofstream os("all_sorting_data.data"); // Öppna filen för att skriva all data

    if (os.is_open())
    {
        os << "N\t"
           << "T[ms]\t"
           << "dev[ms]\t"
           << "Samples\n";
        // std::cout << "N\t" << "T[ms]\t" << "dev[ms]\t" << "Samples\n";

        int increment = 0;
        for (int iter = 1; iter <= REPETITIONS; iter++)
        {
            increment++;
            // for each iteration, enlarge the vector
            data.resize(SIZE * increment);

            DataGenerator::RandomData(SIZE * increment);
           

            // perform x amount of samples within one iteration
            for (int i = 0; i < SAMPLES; i++)
            {
                // Copy dataset
                copy = data;
                // run it

                period[i] = time_sort(SelectionSort, copy);

                //  period[i] = time_sort(SelectionSort, copy);
                assert(std::is_sorted(copy.begin(), copy.end()));
            }
            // write each data iteration to file

            os << SIZE * increment << "\t" << average_value(period) << "\t" << std_dev(period) << "\t" << SAMPLES << '\n';

            // std::cout << SIZE * increment << "\t" << average_value(period) << "\t" << std_dev(period) << "\t" << SAMPLES << '\n';
        }
        os.close();
    }

    return 0;
}
