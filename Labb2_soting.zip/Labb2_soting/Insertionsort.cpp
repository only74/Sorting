#include "Insertionsort.h"
#include "Timer.h"

std::vector<int> InsertionSort(std::vector<int>& data) {
    for (int i = 1; i < data.size(); i++) {
        int key = data[i];
        int current_index = i - 1;
        
        // Flytta element i data[0..i-1], som är större än key, ett steg framåt
        // tills rätt position hittas för key
        while (current_index >= 0 && data[current_index] > key) {
            data[current_index + 1] = data[current_index];
            current_index = current_index - 1;
        }
        data[current_index + 1] = key;
    }
    return data;
}
