#pragma once
#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H
#include <vector>

std::vector<int> InsertionSort(std::vector<int>& data);

#endif //INSERTIONSORT_H