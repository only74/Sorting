#pragma once
#ifndef DATAGENERATING_H
#define DATAGENERATING_H

#include <vector>
#include <random>

//Created the generator functions as class functions just for fun and to learn, no real reason
//Setting functions to static in order to be able to call the functions like this: DataGenerator::GetRandomData(minNum, maxNum, amount);
class DataGenerator{
  public:
    static std::vector<int> RandomData(int size);
    static std::vector<int> DescendingData(int size);
    static std::vector<int> AscendingData(int size);
    static std::vector<int> ConstantData(int value ,int size);
};

#endif //DATAGENERATOR_H